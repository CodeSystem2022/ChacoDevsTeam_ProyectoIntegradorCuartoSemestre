package com.utntecnicatura.patitaspetshopparent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PatitaspetshopparentApplication {

	public static void main(String[] args) {
		SpringApplication.run(PatitaspetshopparentApplication.class, args);
	}

}
